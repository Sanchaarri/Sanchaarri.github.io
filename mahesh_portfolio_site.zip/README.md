# Mahesh Kandgule - Portfolio

This is the source code for Mahesh Kandgule's personal portfolio website.

Live at: `https://sanchaarri.github.io`

## Features
- Minimalist dark theme
- Custom sections: About, Skills, Projects, Experience, Contact
- Responsive layout
